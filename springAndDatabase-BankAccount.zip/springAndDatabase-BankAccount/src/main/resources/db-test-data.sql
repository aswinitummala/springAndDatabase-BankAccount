insert into account(id, name, balance) values (1, "Aswini Tummala", 2000);
insert into account(id, name, balance) values (2, "Aswini", 1000);